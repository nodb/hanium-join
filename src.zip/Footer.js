import React from "react";

const Footer=()=>{
    return(
        <footer className="footer mt-auto py-3 bg-light">
            <span className="text-muted">Place sticky footer content here.</span>
        </footer>

    );
}

export default Footer;