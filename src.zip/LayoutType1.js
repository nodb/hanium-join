import React from "react";
import Page from "./Page";

const LayoutType1=()=>{
    return(
        <Page title="로그인">
            <input type="text" name="abc"></input>
        </Page>
    )
}

export default LayoutType1;