import React from "react";
import Navbar from "./Navbar";
import imgfile from "./images/assign_example.PNG";
import styles from "./LayoutType2.module.css";

export const LayoutType2 = () => {
  const count = 0;

  return (
    <div className={styles.wrapper}>
      <div className="row">
        <Navbar />
        <main className="col-md-9 ms-sm-auto col-lg-10 px-md-4">
          <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
            <h1 className="h4">과제명</h1>
          </div>
          <div id="content_text">
            <table class="table table-bordered" border="1">
              <tr>
                <td class="textviewer" height="200px">
                  <div>과제 설명 예시 칸</div>
                </td>
              </tr>
            </table>
          </div>
          <tr>
            <img src={imgfile} />
          </tr>
          <tr>
            <label for="comment" style={{ fontSize: "14px" }}>
              댓글 {count}개
            </label>
            <div class="d-flex pd-4">
              <div class="form-group">
                <input
                  class="form-control"
                  id="exampleFormControlTextarea1"
                  rows="3"
                />
              </div>
              <div class="form-group">
                <button type="submit" class="btn btn-secondary">
                  확인
                </button>
              </div>
            </div>
          </tr>
          <div class="form-inline pb-4">
            <a href="#">과제 제출하러 가기</a>
          </div>
          <tr>
            <button
              href="#"
              class="btn btn-secondary btn-sm"
              style={{ fontSize: "12px" }}
            >
              목록
            </button>
          </tr>
        </main>
      </div>
    </div>
  );
};

export default LayoutType2;
