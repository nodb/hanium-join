import React, { useState } from "react";
import Navbar from "./Navbar";
import styles from "./LayoutType2.module.css";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Button, Form, FormGroup, Label, Input, FormText } from "reactstrap";

export const P10 = ({list}) => {

  return (
    <div className={styles.wrapper}>
      <div className="row">
        <Navbar />
        <main className="col-md-9 ms-sm-auto col-lg-10 px-md-4">
          {
              list
          }
        </main>
      </div>
    </div>
  );
};

export default P10;
