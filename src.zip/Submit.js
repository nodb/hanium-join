import React, { useState } from "react";
import Navbar from "./Navbar";
import styles from "./LayoutType2.module.css";
import {
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  Card,
  Button,
  CardTitle,
  CardText,
  Row,
  Col,
} from "reactstrap";
import Dropzone from "react-dropzone";
import classnames from "classnames";

const Submit = () => {
  const [activeTab, setActiveTab] = useState("1");

  const toggle = (tab) => {
    if (activeTab !== tab) setActiveTab(tab);
  };
  return (
    <div className={styles.wrapper}>
      <div className="row">
        <Navbar />
        <main className="col-md-9 ms-sm-auto col-lg-10 px-md-4">
          <div className="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
            <h1 className="h4">과제제출</h1>
          </div>
          <Nav tabs>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === "1" })}
                onClick={() => {
                  toggle("1");
                }}
              >
                과제 제출
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink
                className={classnames({ active: activeTab === "2" })}
                onClick={() => {
                  toggle("2");
                }}
              >
                토론하기
              </NavLink>
            </NavItem>
          </Nav>
          <TabContent activeTab={activeTab}>
            <TabPane tabId="1">
              <Row>
                <Col sm="12">
                  <textarea class="form-control mt-4" rows="10"></textarea>
                  <hr />
                  <Dropzone
                    onDrop={(acceptedFiles) => console.log(acceptedFiles)}
                  >
                    {({ getRootProps, getInputProps }) => (
                      <section>
                        <div {...getRootProps()}>
                          <input {...getInputProps()} />
                          <div
                            style={{
                              border: "1px dashed gray",
                              height: "200px",
                              textAlign: "center",
                              lineHeight: "200px",
                            }}
                          >
                            <p>Drag & Drop Files Here</p>
                          </div>
                        </div>
                      </section>
                    )}
                  </Dropzone>

                  <div class="mt-5 d-flex" style={{ float: "right" }}>
                    <Button
                      color="secondary"
                      size="sm"
                      style={{ marginRight: "8px" }}
                    >
                      취소
                    </Button>
                    <Button color="secondary" size="sm">
                      제출
                    </Button>
                  </div>
                </Col>
              </Row>
            </TabPane>
          </TabContent>
        </main>
      </div>
    </div>
  );
};

export default Submit;
